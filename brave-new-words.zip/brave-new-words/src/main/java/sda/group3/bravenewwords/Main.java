package sda.group3.bravenewwords;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws SQLException {
        //1. choosing how many players (3-4) -

        // 2.questions - viena fukncija kas uzdod jautājumu
        // 3. answers - collecting and saving answers to specific question (maps - key- questions, value <list>- answers)
        //3.5. collecting answers and checking with whitelist, and then saving if they are okey

        //4.generating "story" ->

        // 5.show story, probably "for"(as separate method (if we have time)- formating that all words is small letters, spacing)

        // 6.database for "story", unformated story in database

        // 7. rerun programm - option tho choose if want to play again

        Functionality functionality = new Functionality();

        //stores game questions in String array
        final String who = "Who? / What?";
        final String withWho = "With whom / what?";
        final String when = "When?";
        final String where = "Where?";
        final String didWhat = "Did what?";
        final String why = "Why?";
        String[] keys = new String[6];
        keys[0] = who;
        keys[1] = withWho;
        keys[2] = when;
        keys[3] = where;
        keys[4] = didWhat;
        keys[5] = why;

        // stores which player's data we are working with
        int player = 1;

        // stores player's answer to specific question
        String answer;

        // stores player's final story
        String[] playerStory;

        //stores all final stories of all players / key = playerName, value = playerStory
        Map<String, String[]> resultOfGameFinalStory = new HashMap<>();


        //Connect to database for storing answers and accessing whitelist
        Connection connection = Database.getConnection();
        if (connection == null) {
            System.out.println("We ain't able to connect to the database");
        } else {
            Database.createTable(connection);

            // Welcome text
            System.out.println("Please write your answers to following question:");

            //Asking how many players will play
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter Number of Players: ");
            int givenPlayers = scanner.nextInt();


            /// stores players' names
            String[] playerNames = new String[givenPlayers];
            int indexForPlayerName = 0;



            //asking questions and saving answers

            do {
                //asking player's name and adding it to the String Array
                System.out.println("Enter player's name: ");
                String enteredName = scanner.next();
                playerNames[indexForPlayerName] = enteredName;

               //asking questions, storing answers in the Map (Functionality Class)
                System.out.println("Player " + enteredName + " give your answers: ");
                for (int i = 0; i < keys.length; i++) {
                    answer = functionality.askQuestion(keys[i]);
                    functionality.addAnswer(keys[i], answer);
                }
                player++;
                indexForPlayerName++;
            } while (player < givenPlayers + 1);

            //For TESTS
            //System.out.println("Map content BEFORE STORY: " + functionality.answers.toString());

            //Resetting values to create stories for every player
            player = 1;
            indexForPlayerName = 0;


            do {
                //creating random story for each player
                playerStory = functionality.creatingTheStory(keys);

                // adding story to the Map of results
                resultOfGameFinalStory.putIfAbsent(playerNames[indexForPlayerName], playerStory);
                //FOR TESTS:
                // System.out.println("Map content after STORY: " + functionality.answers.toString());
                //System.out.println("Second-FINAL  MAP:  "+resultOfGameFinalStory.toString());

                // saving story in the database
                Database.insertIntoTable(connection, playerNames[indexForPlayerName], playerStory);
                player++;
                indexForPlayerName++;
            } while (player < givenPlayers + 1);

            //Resetting values to print the story for every player
            player = 1;
            indexForPlayerName=0;


            for (int i = 0; i < givenPlayers; i++) {
                System.out.println("Story for Player " + player+":  "+playerNames[indexForPlayerName]);
                String[] story = resultOfGameFinalStory.get(playerNames[indexForPlayerName]);
                functionality.printStory(story);
                player++;
                indexForPlayerName++;
            }

//HAPPY END !
        }
    }
}
